import { html, nothing } from "../../node_modules/lit-html/lit-html.js";
import {
  deleteFactById,
  getFactById,
  getAllLikesByFactId,
  getAllLikesByFactIdAndUserId,
  likeFactById,
} from "../api/data.js";

const detailsTemplate = (a, likes, user, isAlreadyLiked, onDelete, onLike) => {
  const isCreator = a._ownerId === user?._id;

  return html`
  <section id="details">
    <div id="details-wrapper">
  <img id="details-img" src="${a.imageUrl}" alt="example1" />
  <p id="details-category">${a.category}</p>
  <div id="info-wrapper">
    <div id="details-description">
      <p id="category">
      ${a.description}
        </p>
         <p id ="more-info">
         ${a.moreInfo}
              </p>
    </div>
        <h3 id="likes">Likes: <span id="likes-count">${likes}</span></h3>

        <!--Edit and Delete are only for creator-->
        ${user
          ? html`
              <div id="action-buttons">
                ${!isCreator && !isAlreadyLiked
                  ? html`<a href="" id="like-btn" @click=${onLike}>Like</a>`
                  : nothing}
                ${isCreator
                  ? html`
                      <a href="/edit/${a._id}" id="edit-btn">Edit</a>
                      <a href="" id="delete-btn" @click=${onDelete}>Delete</a>
                    `
                  : nothing}
              </div>
            `
          : nothing}
          </div>
      </div>
    </section>
  `;
};

export async function showDetails(ctx) {
  // 1) render(template, container)
  // or
  // 2) ctx.render(template)

  const factId = ctx.params.id;

  // TODO:
  // use Promise.all for album & likes requests

  const fact = await getFactById(factId);

  const likes = await getAllLikesByFactId(factId);

  let isAlreadyLiked = false;

  if (ctx.user) {
    isAlreadyLiked = !!(await getAllLikesByFactIdAndUserId(
      factId,
      ctx.user._id
    ));
  }

  ctx.render(
    detailsTemplate(fact, likes, ctx.user, isAlreadyLiked, onDelete, onLike)
  );

  async function onLike() {
    try {
      likeFactById({ factId: fact._id });

      ctx.page.redirect("/details/" + factId);
    } catch (err) {
      console.log(err.message);
    }
  }

  async function onDelete() {
    try {
      await deleteFactById(factId);

      ctx.page.redirect("/dashboard");
    } catch (err) {
      console.log(err.message);
    }
  }
}


