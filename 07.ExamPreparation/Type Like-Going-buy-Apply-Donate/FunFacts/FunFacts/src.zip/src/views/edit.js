import { html } from "../../node_modules/lit-html/lit-html.js";
import { getFactById, updateFactById } from "../api/data.js";

const editTemplate = (a, onEdit) => html`
<section id="edit">
        <div class="form">
          <h2>Edit Fact</h2>
          <form class="edit-form" @submit=${onEdit}>
        
              <input
              type="text"
              name="category"
              id="category"
              placeholder="Category"
              value=${a.category}
            />
            <input
              type="text"
              name="image-url"
              id="image-url"
              placeholder="Image URL"
              value=${a.imageUrl}
            />
            <textarea
            id="description"
            name="description"
            placeholder="Description"
            rows="10"
            cols="50"
            value=${a.description}
          ></textarea>
          <textarea
            id="additional-info"
            name="additional-info"
            placeholder="Additional Info"
            rows="10"
            cols="50"
            value=${a.moreInfo}
          ></textarea>

            <button type="submit">post</button>
          </form>
        </div>
      </section>
`;

export async function showEdit(ctx) {
  // 1) render(template, container)
  // or
  // 2) ctx.render(template)

  const album = await getFactById(ctx.params.id)

  ctx.render(editTemplate(album, onEdit));

  async function onEdit(event) {
    event.preventDefault()

    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);

    console.log("data", data);

    if (
        !data.category ||  
        !data.imageUrl || 
        !data.description ||
        !data.moreInfo) { 
        return;
      }

      try {
        await updateFactById(ctx.params.id, data);

        ctx.page.redirect("/edit/" + ctx.params.id)
      } catch (err) {
        console.log(err.message);
      }

  }
}
