import { html } from "../../node_modules/lit-html/lit-html.js";
import { createFact } from "../api/data.js";

const createTemplate = (onSubmit) => html`
<section id="create">
        <div class="form">
          <h2>Add Fact</h2>
          <form class="create-form" @submit=${onSubmit}>
          <input
                type="text"
                name="category"
                id="category"
                placeholder="Category"
              />
              <input
                type="text"
                name="image-url"
                id="image-url"
                placeholder="Image URL"
              />
              <textarea
              id="description"
              name="description"
              placeholder="Description"
              rows="10"
              cols="50"
            ></textarea>
            <textarea
              id="additional-info"
              name="additional-info"
              placeholder="Additional Info"
              rows="10"
              cols="50"
            ></textarea>

            <button type="submit">Add Fact</button>
            </form>
          </div>
        </section>
`

export function showCreate(ctx) {
    // 1) render(template, container)
    // or
    // 2) ctx.render(template)

    ctx.render(createTemplate(onSubmit))

    async function onSubmit(event) {
        event.preventDefault();

        const formData = new FormData(event.target);
        const data = Object.fromEntries(formData);

        if (
            !data.category ||  
            !data.imageUrl || 
            !data.description ||
            !data.moreInfo) { 
              return;
            }

        try {
            await createFact(data);

            ctx.page.redirect("/dashboard");
        } catch (err) {
            console.log(err.message);
        }

    }
}
