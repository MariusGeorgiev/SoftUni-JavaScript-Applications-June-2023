import * as api from "./api.js";

export async function getAllFacts() {
  return api.get("/data/facts?sortBy=_createdOn%20desc");
}

export async function getFactById(id) {
  return api.get("/data/facts/" + id);
}

export async function createFact(data) {
  return api.post("/data/facts", data);
}

export async function updateFactById(id, data) {
  return api.put("/data/facts/" + id, data);
}

export async function deleteFactById(id) {
  return api.del("/data/facts/" + id);
}

export async function likeFactById(data) {
  return api.post("/data/likes", data);
}

export async function getAllLikesByFactId(factId) {
  // /data/likes?where= albumId%3D%22{albumId}%22 & distinct=_ownerId & count
  //  /data/likes?where=albumId%3D%22{albumId}%22&distinct=_ownerId&count

  return api.get(
    `/data/likes?where=${encodeURIComponent(
      `factId="${factId}"`
    )}&distinct=_ownerId&count`
  );
}

export async function getAllLikesByFactIdAndUserId(factId, userId) {
  // /data/likes?where=albumId%3D%22{albumId}%22%20and%20_ownerId%3D%22{userId}%22&count

  // /data/likes?where=albumId%3D%22126777f5-3277-42ad-b874-76d043b069cb%22%20and%20_ownerId%3D%2235c62d76-8152-4626-8712-eeb96381bea8%22&count

  // /data/likes?where=albumId%3D%22126777f5-3277-42ad-b874-76d043b069cb%22and_ownerId%3D%2235c62d76-8152-4626-8712-eeb96381bea8%22&count

  const url = `/data/likes?where=${encodeURIComponent(
    `factId="${factId}"`
  )}%20and%20${encodeURIComponent(`_ownerId="${userId}"`)}&count`;

  console.log(url);

  return api.get(
    `/data/likes?where=${encodeURIComponent(
      `factId="${factId}"`
    )}%20and%20${encodeURIComponent(`_ownerId="${userId}"`)}&count`
  );
}