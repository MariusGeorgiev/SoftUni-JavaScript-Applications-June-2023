import { getAll } from '../api/data.js';
import { html } from '../lib.js';

// this is dashboard also
const catalogTemplate = (events) => html`
<h2>Current Events</h2>
<section id="dashboard">
  ${events.length == 0
    ? html`<h4>No Events yet.</h4>`
    : events.map(
        (e) => html`       
        <div class="event">
    <img src="${e.imageUrl}" alt="example1" />
    <p class="title">
    ${e.name}
    </p>
    <p class="date">${e.date}</p>
    <a class="details-btn" href="/details/${e._id}">Details</a>
  </div>
        `
      )}
</section>`;

export async function showCatalog(ctx) {
    const events = await getAll();

    ctx.render(catalogTemplate(events));
}
