import { deleteItem, getById, getTotalGoings, getUserGoing, getGoing } from '../api/data.js';
import { html, nothing } from '../lib.js';


const detailsTamplate = (
  event,
  isOwner,
  onDelete,
  isLoggedIn,
  totalGoesCount,
  onClickGo,
  didUserGoin
  


) => html`
<section id="details">
          <div id="details-wrapper">
            <img id="details-img" src="${event.imageUrl}" alt="example1" />
            <p id="details-title">${event.name}</p>
            <p id="details-category">
              Category: <span id="categories">${event.category}</span>
            </p>
            <p id="details-date">
              Date:<span id="date">${event.date}</span></p>
            <div id="info-wrapper">
              <div id="details-description">
                <span>${event.description}</span>
              </div>

            </div>

            <h3>Going: <span id="go">${totalGoesCount}</span> times.</h3>

        <div id="action-buttons">

        ${(() => {
    if (isLoggedIn && isOwner) {
      return html`
            <a href="/edit/${event._id}" id="edit-btn">Edit</a>
            <a href="javascript:void(0)" id="delete-btn" @click=${onDelete}>Delete</a>
            `
    }

  })()}
            ${(() => {
    if (isLoggedIn && !isOwner) {
      if(!didUserGoin) {return html`
            <a href="javascript:void(0)" id="go-btn" @click=${onClickGo}>Going</a>
            `}
      
    }

  })()}

              
            </div>
          </div>
          </div>
          </div>
        </section>
       

`;

export async function detailsPage(ctx) {
  const eventId = ctx.params.id;
  const event = await getById(eventId);
  const user = ctx.user;

  let userId;
  let totalGoesCount;
  let didUserGoin;

  if (user != null) {
    userId = user._id;
    didUserGoin = await getUserGoing(eventId, userId);
  }

  const isOwner = user && event._ownerId == user._id;
  const isLoggedIn = user !== undefined;

  totalGoesCount = await getTotalGoings(eventId);
  ctx.render(
    detailsTamplate(
      event,
      isOwner,
      onDelete,
      isLoggedIn,
      totalGoesCount,
      onClickGo,
      didUserGoin
    )
  );

  async function onClickGo() {
    const donation = {
       eventId,
    };
    await getGoing(donation);

    totalGoesCount = await getTotalGoings(eventId);
    didUserGoin = await getUserGoing(eventId, userId);
    ctx.render(
      detailsTamplate(
        event,
        isOwner,
        onDelete,
        isLoggedIn,
        totalGoesCount,
        onClickGo,
        getUserGoing
      )
    );
  }

  async function onDelete() {
    const confirmed = confirm("Are you sure?");
    if (confirmed) {
      await deleteItem(eventId);
      ctx.page.redirect("/dashboard");
    }
  }
}

